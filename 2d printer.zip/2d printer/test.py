from PyQt5.QtWidgets import QMainWindow, QApplication
from Ui_printer import Ui_MainWindow
import sys


from Ui_printer import Ui_MainWindow
Filename = ''
class UI:
    def __init__(self):
        self.Main = QMainWindow()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self.Main)

        self.Main.show()







app = QApplication([])

UImain = UI()
sys.exit(app.exec_())
