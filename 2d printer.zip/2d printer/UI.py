from PyQt5.QtWidgets import QApplication, QWidget,QStackedWidget, QPushButton, QVBoxLayout,QGraphicsView, QWizard, QMainWindow, QLabel,QDialog, QFileDialog,QMessageBox

from PyQt5 import QtGui
from PyQt5 import uic
import sys
import qdarkstyle
from pictoplot.new import *
import os
from PyQt5.QtCore import *
from PyQt5.QtGui import *

from Ui_printer import Ui_MainWindow
Filename = ''
class UI:
    def __init__(self):
        self.Main = QMainWindow()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self.Main)
        # load 
        # uic.loadUi("Printer.ui",self)

        # Initialize widgets from UI
        # self.lbl1 = self.findChild(QLabel,"label")
        # self.lbl2 = self.findChild(QLabel,"label_2")
        # self.img1 = self.findChild(QLabel,"label_3")
        # self.img2 = self.findChild(QLabel,"label_4")
        # self.browse_btn = self.findChild(QPushButton,"Choose_img_btn")
        # self.draw_btn = self.findChild(QPushButton,"Draw_btn")
        # self.selfie_btn = self.findChild(QPushButton,"Take_pic_btn")
        # self.cancel_btn = self.findChild(QPushButton,"Cancel_btn")
        # self.page = self.findChild(QStackedWidget,"stackedWidget")
        

        # Initialize 
        self.ui.stackedWidget.setCurrentIndex(0)
        self.ui.Choose_img_btn.clicked.connect(self.BrowseImage)
        self.ui.Draw_btn.clicked.connect(self.Draw)
        self.ui.Cancel_btn.clicked.connect(self.Cancel)
        # self.browse_btn.clicked.connect(self.BrowseImage)
        # self.draw_btn.clicked.connect(self.Draw)
        self.ui.label_3.setStyleSheet("border: 1px solid black;")
        self.ui.label_4.setStyleSheet("border: 1px solid black;")
        self.Main.show()



    def BrowseImage(self):
        fname = QFileDialog.getOpenFileName(None,'Open File', 'c:\\', 'Image files (*.jpg *png)')
        global Filename
        imagepth = fname[0]
        if(imagepth == ""):
            return

        else:
            self.ui.stackedWidget.setCurrentIndex(1)
            head ,tail = os.path.split(imagepth)    
            filename = tail.split('.')
        
            pixmap = QtGui.QPixmap(imagepth)
            self.ui.label_3.setPixmap(QtGui.QPixmap(imagepth))
            img2bmp(imagepth,filename)
            CovertToPBM(0.3,filename)
        
            pixmap1 = QtGui.QPixmap('./PBM images/'+filename[0]+'.pbm')
            self.ui.label_4.setPixmap(pixmap1)
            Filename = filename[0]
          
           
            
            
            
    def Cancel(self):
        self.ui.stackedWidget.setCurrentIndex(0)
       

    def Draw(self):
        
        if self.ui.label_3.pixmap()== None:
            msg = QMessageBox()
            msg.setIcon(QMessageBox.Critical)
            msg.setText("Error")
            msg.setInformativeText('Choose image first')
            msg.setWindowTitle("Error")
    
            x= msg.exec_()
        else:
            global Filename
            ConvertToSVG(Filename)
            FixSvgHeader(Filename)
            ConvertToGCode(Filename)
         

if __name__ == '__main__':

    app = QApplication(sys.argv)
    app.setStyleSheet(qdarkstyle.load_stylesheet())
    UImain = UI()
    sys.exit(app.exec_())